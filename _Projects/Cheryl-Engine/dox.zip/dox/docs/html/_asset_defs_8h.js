var _asset_defs_8h =
[
    [ "Factory", "class_game_assets_1_1_factory.html", "class_game_assets_1_1_factory" ],
    [ "GameAsset", "class_game_assets_1_1_game_asset.html", "class_game_assets_1_1_game_asset" ],
    [ "Texture", "class_game_assets_1_1_texture.html", "class_game_assets_1_1_texture" ],
    [ "VO_Data", "class_game_assets_1_1_v_o___data.html", "class_game_assets_1_1_v_o___data" ],
    [ "BUFFER_OFFSET", "_asset_defs_8h.html#a063a3af905ecefe83d76ca3f0fe0653e", null ],
    [ "TYPE_ID_IMPL", "_asset_defs_8h.html#a53122c8dd3a0806b87d8648523feeded", null ],
    [ "useMipMaps", "_asset_defs_8h.html#a49d466d14b928a06d3cfcb8c85537407", null ]
];