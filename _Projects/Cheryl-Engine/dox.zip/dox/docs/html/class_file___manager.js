var class_file___manager =
[
    [ "Get_Files", "class_file___manager.html#a5fe0ef2e3f074a407681eb6e4bb758a8", null ],
    [ "Register_Directory", "class_file___manager.html#a718de9b248d6f7ac0ce1ed88c090455f", null ]
];