var searchData=
[
  ['s3d_5fmesh_5fmgr',['s3d_mesh_mgr',['../classs3d__mesh__mgr.html#a771c42fd825a407b834d843a2daebb92',1,'s3d_mesh_mgr']]],
  ['set_5fshader',['set_shader',['../class_sprite___manager.html#a86f83baee7a882cb7f4155736a320db5',1,'Sprite_Manager::set_shader()'],['../classs3d__mesh__mgr.html#aa7ed8cf9c02ef5844396376d5867fb7a',1,'s3d_mesh_mgr::set_Shader()']]]
];
