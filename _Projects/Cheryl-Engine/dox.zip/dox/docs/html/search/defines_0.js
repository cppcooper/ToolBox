var searchData=
[
  ['buffer_5foffset',['BUFFER_OFFSET',['../_asset_defs_8h.html#a063a3af905ecefe83d76ca3f0fe0653e',1,'AssetDefs.h']]]
];
