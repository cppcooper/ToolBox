var texture__mgr_8h =
[
    [ "Texture_Manager", "class_texture___manager.html", "class_texture___manager" ],
    [ "TEXTURE_MANAGER_MAX_TEXTURES", "texture__mgr_8h.html#a3ac24b0a1e5c9bd67e73d9c9992d9685", null ]
];