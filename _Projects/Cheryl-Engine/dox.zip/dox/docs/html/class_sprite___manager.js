var class_sprite___manager =
[
    [ "~Sprite_Manager", "class_sprite___manager.html#ae33cb3bc8c9818e40c5d1454068aa7e8", null ],
    [ "Get_Sprite", "class_sprite___manager.html#ad1e02f2b2acabc8a1d1fe299b54b39f7", null ],
    [ "Load_All", "class_sprite___manager.html#a5e4499eb9f8d9928949960f31b11c263", null ],
    [ "Load_Sprite", "class_sprite___manager.html#adf9fcd93a4751062b73150359a123086", null ],
    [ "Load_Sprite_Sheet", "class_sprite___manager.html#a80661642ec7310a83fbea09cc6b614a0", null ],
    [ "set_shader", "class_sprite___manager.html#a86f83baee7a882cb7f4155736a320db5", null ]
];