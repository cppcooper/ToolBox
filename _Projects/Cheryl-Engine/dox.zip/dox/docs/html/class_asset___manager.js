var class_asset___manager =
[
    [ "GetAsset", "class_asset___manager.html#a4896b45aebeeb82fa52d626596cfb4e9", null ],
    [ "RecordAsset", "class_asset___manager.html#ae4f2715facfd9492fb9ba9457c50ab95", null ]
];