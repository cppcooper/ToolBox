var dir_5251b65e414bc66c2d9eeb3dbd5e8279 =
[
    [ "GameFaculties", "dir_3babd57e1da073f24fcc2aa0b8378a39.html", "dir_3babd57e1da073f24fcc2aa0b8378a39" ]
];