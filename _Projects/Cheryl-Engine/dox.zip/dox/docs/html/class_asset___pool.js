var class_asset___pool =
[
    [ "Get", "class_asset___pool.html#a04a61a8f9a333f48b90e92fa2862479b", null ],
    [ "Return", "class_asset___pool.html#a0f4fa57e8d024e6b9e734cdfae0a6310", null ],
    [ "Update", "class_asset___pool.html#a3ea6d4f63f039b6bed28650fba00b78a", null ],
    [ "Object_Pools", "class_asset___pool.html#a7c0f6690c95d5eb38b8a66908fdfb8c9", null ]
];