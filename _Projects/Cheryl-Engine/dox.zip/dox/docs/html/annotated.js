var annotated =
[
    [ "GameAssets", "namespace_game_assets.html", "namespace_game_assets" ],
    [ "Asset_Factory", "class_asset___factory.html", "class_asset___factory" ],
    [ "Asset_Faculties", "class_asset___faculties.html", "class_asset___faculties" ],
    [ "Asset_Loader", "class_asset___loader.html", "class_asset___loader" ],
    [ "Asset_Manager", "class_asset___manager.html", "class_asset___manager" ],
    [ "Asset_Pool", "class_asset___pool.html", "class_asset___pool" ],
    [ "Asset_Storage", "class_asset___storage.html", "class_asset___storage" ],
    [ "File_Manager", "class_file___manager.html", "class_file___manager" ],
    [ "s3d_mesh_mgr", "classs3d__mesh__mgr.html", "classs3d__mesh__mgr" ],
    [ "ShaderManager", "class_shader_manager.html", "class_shader_manager" ],
    [ "Sprite_Manager", "class_sprite___manager.html", "class_sprite___manager" ],
    [ "Texture_Manager", "class_texture___manager.html", "class_texture___manager" ]
];